<?php
$MESS["PRODUCT_CANCEL"] = "Товар в статусе отмены";
