<?php
$MESS["ROOT_CATEGORY_FOR_CATALOG"] = "Корневой раздел для каталога \"%s\"";
