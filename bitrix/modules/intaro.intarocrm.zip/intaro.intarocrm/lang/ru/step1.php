<?php
$MESS ['STEP_NAME'] = 'Шаг 1';
$MESS ['MOD_NEXT_STEP'] = 'Следующий шаг';
$MESS ['ICRM_API_HOST'] = 'Адрес IntaroCRM:';
$MESS ['ICRM_API_KEY'] = 'Ключ авторизации:';
$MESS ['ICRM_SITES'] = 'Активные сайты:';
$MESS ['ERR_404'] = 'Возможно неверно введен адрес IntaroCRM.';
$MESS ['ERR_403'] = 'Неверный apiKey.';
$MESS ['ERR_0'] = 'Превышено время ожидания ответа от сервера.';
$MESS ['ERR_FIELDS_API_HOST'] = 'Неверно заполнены поля.';
$MESS ['INFO_1'] = 'Введите адрес экземпляра IntaroCRM (например, https://demo.intarocrm.ru) и API-ключ.';
$MESS ['INFO_2'] = 'API-ключ можно сгенерировать при регистрации магазина в IntaroCRM (Администрирование > Интеграция).';
$MESS ['INFO_3'] = 'Код сайта в 1С-Битрикс должен совпадать с кодом сайта в IntaroCRM (Администрирование > Магазины).';