<?
//<title>retailCRM</title>
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/intaro.intarocrm/export/export_setup.php");