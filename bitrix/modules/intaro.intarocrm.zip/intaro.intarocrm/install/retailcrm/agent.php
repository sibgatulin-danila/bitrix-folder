<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/intaro.intarocrm/classes/general/agent.php');