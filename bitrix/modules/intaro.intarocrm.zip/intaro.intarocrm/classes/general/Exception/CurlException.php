<?php

namespace RetailCrm\Exception;

class CurlException extends \RuntimeException
{
}
