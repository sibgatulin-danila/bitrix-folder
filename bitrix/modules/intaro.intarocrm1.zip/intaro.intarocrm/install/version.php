
<?
$arModuleVersion = array(
    "VERSION" => "1.1.2",
    "VERSION_DATE" => "2015-05-19 16:33:53"
);

