<?php

namespace RetailCrm\Exception;

class InvalidJsonException extends \DomainException
{
}
